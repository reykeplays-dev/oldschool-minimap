const MODULE_ID = "oldschool-minimap";

class OldschoolMinimap {
  static element = null;
  static canvas = null;
  static ctx = null;
  static toolbar = null;
  static status = null;
  static chatMoveRequests = {};

  static gridSize = 14;
  static cellSize = 20;
  static canvasSize = 280;

  static activeTool = "move-party";

  static visibilityModes = {
    HIDDEN: 0,
    SETUP: 1,
    LIVE: 2
  };

  static markerTypes = {
    monster: {
      label: "Monster",
      symbol: "M",
      gmOnly: true
    },
    trap: {
      label: "Trap",
      symbol: "!",
      gmOnly: true
    },
    treasure: {
      label: "Treasure",
      symbol: "$",
      gmOnly: false
    },
    boss: {
      label: "Boss",
      symbol: "B",
      gmOnly: false
    }
  };

  static init() {
    console.log("Oldschool Minimap | Initializing module.");

    game.settings.register(MODULE_ID, "position", {
      scope: "client",
      config: false,
      type: Object,
      default: {}
    });

    game.settings.register(MODULE_ID, "visibilityMode", {
      name: "Dungeon Tracker Visibility Mode",
      hint: "0 = hidden, 1 = GM setup only, 2 = live for everyone.",
      scope: "world",
      config: false,
      type: Number,
      default: this.visibilityModes.HIDDEN,
      onChange: () => {
        this.refreshSceneControls();
        this.render();
      }
    });

    game.settings.register(MODULE_ID, "dungeonData", {
      scope: "world",
      config: false,
      type: Object,
      default: this.defaultDungeonData(),
      onChange: () => this.draw()
    });

    Hooks.on("getSceneControlButtons", controls => {
      this.registerSceneControlButton(controls);
    });

    Hooks.once("ready", () => {
      console.log("Oldschool Minimap | Ready hook fired.");
      this.refreshSceneControls();
      this.loadExistingMovementRequestsFromChat();
      this.render();
    });

    Hooks.on("canvasReady", () => {
      this.render();
    });

    Hooks.on("oldschoolMinimapUpdated", () => this.draw());

    Hooks.on("createChatMessage", message => {
      this.handleMovementRequestChatMessage(message);
    });

    Hooks.on("deleteChatMessage", message => {
      this.handleDeletedMovementRequestChatMessage(message);
    });

    game.socket.on(`module.${MODULE_ID}`, payload => {
      this.handleSocketMessage(payload);
    });
  }

  static defaultDungeonData() {
    return {
      rooms: {},
      discoveredRooms: {},
      markers: {},
      moveRequests: {},
      party: null
    };
  }

  static normalizeData(data) {
    const normalized = foundry.utils.deepClone(data ?? this.defaultDungeonData());

    normalized.rooms ??= {};
    normalized.discoveredRooms ??= {};
    normalized.markers ??= {};
    normalized.moveRequests ??= {};
    normalized.party ??= null;

    return normalized;
  }

  static getData() {
    const data = game.settings.get(MODULE_ID, "dungeonData");
    return this.normalizeData(data);
  }

  static async setData(data, broadcast = true) {
    if (!game.user.isGM) {
      ui.notifications.warn("Only the GM can directly change the dungeon tracker.");
      return;
    }

    const normalized = this.normalizeData(data);

    await game.settings.set(MODULE_ID, "dungeonData", normalized);

    if (broadcast) {
      game.socket.emit(`module.${MODULE_ID}`, {
        type: "data-updated"
      });
    }

    Hooks.callAll("oldschoolMinimapUpdated");
  }

  static getVisibilityMode() {
    return Number(game.settings.get(MODULE_ID, "visibilityMode") ?? this.visibilityModes.HIDDEN);
  }

  static isHiddenMode() {
    return this.getVisibilityMode() === this.visibilityModes.HIDDEN;
  }

  static isSetupMode() {
    return this.getVisibilityMode() === this.visibilityModes.SETUP;
  }

  static isLiveMode() {
    return this.getVisibilityMode() === this.visibilityModes.LIVE;
  }

  static canCurrentUserSeeTracker() {
    if (this.isHiddenMode()) return false;
    if (this.isSetupMode()) return game.user.isGM;
    if (this.isLiveMode()) return true;
    return false;
  }

  static async cycleVisibilityMode() {
    if (!game.user.isGM) {
      ui.notifications.warn("Only the GM can change the dungeon tracker visibility.");
      return;
    }

    const current = this.getVisibilityMode();
    const next = (current + 1) % 3;

    await game.settings.set(MODULE_ID, "visibilityMode", next);

    game.socket.emit(`module.${MODULE_ID}`, {
      type: "visibility-updated",
      visibilityMode: next
    });

    this.refreshSceneControls();
    this.render();

    ui.notifications.info(`Dungeon Tracker: ${this.getVisibilityLabel(next)}`);
  }

  static getVisibilityLabel(mode = this.getVisibilityMode()) {
    if (mode === this.visibilityModes.HIDDEN) return "Hidden";
    if (mode === this.visibilityModes.SETUP) return "GM Setup";
    if (mode === this.visibilityModes.LIVE) return "Live";
    return "Unknown";
  }

  static getVisibilityIcon(mode = this.getVisibilityMode()) {
    if (mode === this.visibilityModes.HIDDEN) return "fa-solid fa-eye-slash";
    if (mode === this.visibilityModes.SETUP) return "fa-solid fa-user-shield";
    if (mode === this.visibilityModes.LIVE) return "fa-solid fa-map-location-dot";
    return "fa-solid fa-map";
  }

  static refreshSceneControls() {
    try {
      ui.controls?.render?.({ force: true });
    } catch (error) {
      try {
        ui.controls?.render?.(true);
      } catch (fallbackError) {
        console.warn("Oldschool Minimap | Could not refresh scene controls.", fallbackError);
      }
    }
  }

  static registerSceneControlButton(controls) {
    if (!game.user?.isGM) return;

    const mode = this.getVisibilityMode();

    const tool = {
      name: "oldschool-minimap-toggle",
      title: `Dungeon Tracker: ${this.getVisibilityLabel(mode)}`,
      icon: this.getVisibilityIcon(mode),
      order: 99,
      button: true,
      toggle: false,
      active: false,
      visible: true,

      onChange: async () => {
        await this.cycleVisibilityMode();
      },

      onClick: async () => {
        await this.cycleVisibilityMode();
      }
    };

    console.log("Oldschool Minimap | getSceneControlButtons fired.", controls);

    if (controls.tokens?.tools) {
      controls.tokens.tools["oldschool-minimap-toggle"] = tool;
      console.log("Oldschool Minimap | Added toggle to V13 token controls.");
      return;
    }

    if (controls.token?.tools) {
      controls.token.tools["oldschool-minimap-toggle"] = tool;
      console.log("Oldschool Minimap | Added toggle to token controls.");
      return;
    }

    if (Array.isArray(controls)) {
      const tokenControls =
        controls.find(control => control.name === "token") ??
        controls.find(control => control.name === "tokens");

      if (tokenControls) {
        if (Array.isArray(tokenControls.tools)) {
          tokenControls.tools.push(tool);
          console.log("Oldschool Minimap | Added toggle to array token controls.");
          return;
        }

        if (tokenControls.tools && typeof tokenControls.tools === "object") {
          tokenControls.tools["oldschool-minimap-toggle"] = tool;
          console.log("Oldschool Minimap | Added toggle to object token controls in array mode.");
          return;
        }
      }
    }

    if (!Array.isArray(controls) && typeof controls === "object") {
      controls["oldschool-minimap"] = {
        name: "oldschool-minimap",
        title: "Dungeon Tracker",
        icon: "fa-solid fa-map",
        order: 99,
        visible: game.user.isGM,
        tools: {
          "oldschool-minimap-toggle": tool
        },
        activeTool: "oldschool-minimap-toggle"
      };

      console.log("Oldschool Minimap | Added fallback top-level control group.");
      return;
    }

    if (Array.isArray(controls)) {
      controls.push({
        name: "oldschool-minimap",
        title: "Dungeon Tracker",
        icon: "fa-solid fa-map",
        layer: "tokens",
        visible: game.user.isGM,
        tools: [tool],
        activeTool: "oldschool-minimap-toggle"
      });

      console.log("Oldschool Minimap | Added fallback array control group.");
    }
  }

  static handleSocketMessage(payload) {
    if (!payload?.type) return;

    if (payload.type === "visibility-updated") {
      this.refreshSceneControls();
      this.render();
      return;
    }

    if (payload.type === "data-updated") {
      this.draw();
      return;
    }

    // Legacy fallback from older builds. New player movement requests use ChatMessage flags.
    if (payload.type === "request-party-move" && game.user.isGM) {
      this.handleMoveRequestMarker(payload);
      return;
    }
  }

  static async handleMoveRequestMarker(payload) {
    if (!this.isLiveMode()) {
      ui.notifications.warn("Dungeon Tracker: movement request ignored because tracker is not live.");
      return;
    }

    const x = Number(payload.x);
    const y = Number(payload.y);

    if (!Number.isInteger(x) || !Number.isInteger(y)) {
      ui.notifications.warn("Dungeon Tracker: invalid movement request received.");
      return;
    }

    const data = this.getData();
    const key = this.key(x, y);

    const requestingUser = game.users.get(payload.userId);
    const requesterName = requestingUser?.name ?? "A player";

    if (!data.rooms[key]) {
      ui.notifications.warn(`${requesterName} requested movement to ${x}, ${y}, but no room exists there.`);
      return;
    }

    if (!this.isRoomVisibleToPlayers(data, x, y)) {
      ui.notifications.warn(`${requesterName} requested movement to ${x}, ${y}, but that room is not revealed.`);
      return;
    }

    if (!this.canMovePartyTo(data, x, y)) {
      ui.notifications.warn(`${requesterName} requested movement to ${x}, ${y}, but that room is not available.`);
      return;
    }

    data.moveRequests[key] = {
      x,
      y,
      userId: payload.userId,
      userName: requesterName,
      createdAt: Date.now()
    };

    await this.setData(data);

    ui.notifications.info(`${requesterName} requested party movement to ${x}, ${y}.`);
  }

  static getMovementRequestFlag(message) {
    return message?.getFlag?.(MODULE_ID, "movementRequest") ?? null;
  }

  static handleMovementRequestChatMessage(message) {
    const request = this.getMovementRequestFlag(message);
    if (!request) return;

    const x = Number(request.x);
    const y = Number(request.y);

    if (!Number.isInteger(x) || !Number.isInteger(y)) return;

    const key = this.key(x, y);

    this.chatMoveRequests[key] = {
      x,
      y,
      userId: request.userId,
      userName: request.userName,
      messageId: message.id,
      createdAt: request.createdAt ?? Date.now()
    };

    this.draw();
  }

  static handleDeletedMovementRequestChatMessage(message) {
    const request = this.getMovementRequestFlag(message);
    if (!request) return;

    const x = Number(request.x);
    const y = Number(request.y);

    if (!Number.isInteger(x) || !Number.isInteger(y)) return;

    const key = this.key(x, y);

    if (this.chatMoveRequests[key]?.messageId === message.id) {
      delete this.chatMoveRequests[key];
      this.draw();
    }
  }

  static loadExistingMovementRequestsFromChat() {
    this.chatMoveRequests = {};

    for (const message of game.messages ?? []) {
      const request = this.getMovementRequestFlag(message);
      if (!request) continue;

      const x = Number(request.x);
      const y = Number(request.y);

      if (!Number.isInteger(x) || !Number.isInteger(y)) continue;

      const key = this.key(x, y);

      this.chatMoveRequests[key] = {
        x,
        y,
        userId: request.userId,
        userName: request.userName,
        messageId: message.id,
        createdAt: request.createdAt ?? Date.now()
      };
    }

    this.draw();
  }

  static getAllMoveRequests(data) {
    return {
      ...(data.moveRequests ?? {}),
      ...(this.chatMoveRequests ?? {})
    };
  }

  static async createMovementRequestChatMessage(x, y) {
    await ChatMessage.create({
      user: game.user.id,
      speaker: ChatMessage.getSpeaker(),
      content: `<p><strong>Dungeon Tracker:</strong> ${game.user.name} requests movement to <strong>${x}, ${y}</strong>.</p>`,
      flags: {
        [MODULE_ID]: {
          movementRequest: {
            x,
            y,
            userId: game.user.id,
            userName: game.user.name,
            createdAt: Date.now()
          }
        }
      }
    });
  }

  static render() {
    this.element?.remove();
    this.element = null;

    if (!this.canCurrentUserSeeTracker()) {
      return;
    }

    const wrapper = document.createElement("div");
    wrapper.id = "oldschool-minimap";

    if (this.isSetupMode()) {
      wrapper.classList.add("setup-mode");
    }

    const header = document.createElement("header");

    if (game.user.isGM) {
      if (this.isSetupMode()) {
        header.textContent = "DUNGEON TRACKER — GM SETUP";
      } else if (this.isLiveMode()) {
        header.textContent = "DUNGEON TRACKER — LIVE";
      } else {
        header.textContent = "DUNGEON TRACKER — GM";
      }
    } else {
      header.textContent = "DUNGEON TRACKER";
    }

    const map = document.createElement("canvas");
    map.width = this.canvasSize;
    map.height = this.canvasSize;

    const toolbar = document.createElement("div");
    toolbar.classList.add("oldschool-minimap-toolbar");

    const status = document.createElement("div");
    status.classList.add("oldschool-minimap-status");

    wrapper.appendChild(header);
    wrapper.appendChild(map);
    wrapper.appendChild(toolbar);
    wrapper.appendChild(status);
    document.body.appendChild(wrapper);

    this.element = wrapper;
    this.canvas = map;
    this.ctx = map.getContext("2d");
    this.toolbar = toolbar;
    this.status = status;

    this.restorePosition(wrapper);
    this.makeDraggable(wrapper, header);
    this.buildToolbar();
    this.bindCanvasClick();
    this.draw();
  }

  static buildToolbar() {
    if (!this.toolbar) return;

    this.toolbar.innerHTML = "";

    if (game.user.isGM) {
      this.addToolButton("Room", "place-room");
      this.addToolButton("Erase", "erase-room");
      this.addToolButton("Party", "set-party");
      this.addToolButton("Move", "move-party");
      this.addToolButton("Monster", "marker-monster");
      this.addToolButton("Trap", "marker-trap");
      this.addToolButton("Treasure", "marker-treasure");
      this.addToolButton("Boss", "marker-boss");
      this.addToolButton("Clear Mark", "clear-marker");

      this.addButton("Clear Req", async () => {
        const data = this.getData();
        data.moveRequests = {};

        if (game.user.isGM) {
          for (const request of Object.values(this.chatMoveRequests ?? {})) {
            if (!request.messageId) continue;

            const message = game.messages.get(request.messageId);
            if (message) await message.delete();
          }
        }

        this.chatMoveRequests = {};

        await this.setData(data);
        this.setStatus("All movement requests cleared.");
      });

      this.addButton("Reset", async () => {
        const confirmed = await Dialog.confirm({
          title: "Reset Dungeon Tracker?",
          content: "<p>This will delete all rooms, markers, movement requests, party position, and discovery data.</p>"
        });

        if (!confirmed) return;

        if (game.user.isGM) {
          for (const request of Object.values(this.chatMoveRequests ?? {})) {
            if (!request.messageId) continue;

            const message = game.messages.get(request.messageId);
            if (message) await message.delete();
          }
        }

        this.chatMoveRequests = {};

        await this.setData(this.defaultDungeonData());
      });

      if (this.isSetupMode()) {
        this.setStatus("GM setup mode. Players cannot see the tracker.");
      } else if (this.isLiveMode()) {
        this.setStatus(`Live mode. Tool: ${this.activeTool}.`);
      } else {
        this.setStatus(`Tool: ${this.activeTool}.`);
      }
    } else {
      this.addToolButton("Move", "move-party");
      this.setStatus("Click any revealed room to place a movement request.");
    }

    this.refreshToolButtons();
  }

  static addButton(label, onClick) {
    const button = document.createElement("button");
    button.textContent = label;
    button.addEventListener("click", onClick);
    this.toolbar.appendChild(button);
  }

  static addToolButton(label, tool) {
    const button = document.createElement("button");
    button.textContent = label;
    button.dataset.tool = tool;

    button.addEventListener("click", () => {
      this.activeTool = tool;
      this.refreshToolButtons();

      if (tool === "move-party") {
        if (game.user.isGM) {
          this.setStatus("Tool: Move. Click any revealed room.");
        } else {
          this.setStatus("Tool: Move. Click any revealed room to request movement.");
        }
      } else {
        this.setStatus(`Tool: ${label}. Click the grid.`);
      }
    });

    this.toolbar.appendChild(button);
  }

  static refreshToolButtons() {
    if (!this.toolbar) return;

    for (const button of this.toolbar.querySelectorAll("button[data-tool]")) {
      button.classList.toggle("active", button.dataset.tool === this.activeTool);
    }
  }

  static setStatus(message) {
    if (this.status) this.status.textContent = message;
  }

  static bindCanvasClick() {
    this.canvas.addEventListener("click", async event => {
      const cell = this.eventToCell(event);
      if (!cell) return;

      if (game.user.isGM) {
        await this.handleGMClick(cell.x, cell.y);
      } else {
        await this.handlePlayerClick(cell.x, cell.y);
      }
    });
  }

  static async handleGMClick(x, y) {
    const data = this.getData();
    const key = this.key(x, y);

    if (this.activeTool === "place-room") {
      data.rooms[key] = { x, y };
      this.setStatus(`Room placed at ${x}, ${y}.`);
    }

    else if (this.activeTool === "erase-room") {
      delete data.rooms[key];
      delete data.discoveredRooms[key];
      delete data.markers[key];
      delete data.moveRequests[key];

      await this.deleteChatMoveRequestAt(x, y);

      if (data.party?.x === x && data.party?.y === y) {
        data.party = null;
      }

      this.setStatus(`Room erased at ${x}, ${y}.`);
    }

    else if (this.activeTool === "set-party") {
      if (!data.rooms[key]) {
        ui.notifications.warn("Place a room there before setting the party token.");
        return;
      }

      data.party = { x, y };
      this.revealFromParty(data);
      await this.clearMoveRequestAt(data, x, y);
      this.setStatus(`Party token placed at ${x}, ${y}.`);
    }

    else if (this.activeTool === "move-party") {
      if (!data.rooms[key]) {
        ui.notifications.warn("The party can only move into placed rooms.");
        return;
      }

      if (!this.canMovePartyTo(data, x, y)) {
        ui.notifications.warn("The party can only move to a revealed room.");
        return;
      }

      data.party = { x, y };
      this.revealFromParty(data);
      await this.clearMoveRequestAt(data, x, y);
      this.setStatus(`Party moved to ${x}, ${y}.`);
    }

    else if (this.activeTool.startsWith("marker-")) {
      if (!data.rooms[key]) {
        ui.notifications.warn("Place a room before adding a marker.");
        return;
      }

      const markerType = this.activeTool.replace("marker-", "");
      data.markers[key] = markerType;
      this.setStatus(`${this.markerTypes[markerType].label} marker placed at ${x}, ${y}.`);
    }

    else if (this.activeTool === "clear-marker") {
      delete data.markers[key];
      this.setStatus(`Marker cleared at ${x}, ${y}.`);
    }

    this.revealFromParty(data);
    await this.clearInvalidMoveRequests(data);
    await this.setData(data);
  }

  static async handlePlayerClick(x, y) {
    if (!this.isLiveMode()) {
      ui.notifications.warn("The dungeon tracker is not live.");
      return;
    }

    if (this.activeTool !== "move-party") {
      this.activeTool = "move-party";
      this.refreshToolButtons();
    }

    const data = this.getData();
    const key = this.key(x, y);

    if (!data.rooms[key]) return;

    if (!this.isRoomVisibleToPlayers(data, x, y)) {
      ui.notifications.warn("That room has not been revealed.");
      return;
    }

    if (!this.canMovePartyTo(data, x, y)) {
      ui.notifications.warn("You can only request movement to a revealed room.");
      return;
    }

    await this.createMovementRequestChatMessage(x, y);

    ui.notifications.info("Dungeon Tracker: movement request marker placed.");
    this.setStatus(`Movement request placed: ${x}, ${y}.`);
  }

  static revealFromParty(data) {
    if (!data.party) return;

    const { x, y } = data.party;
    const visibleKeys = this.getVisibleRoomKeysFrom(data, x, y);

    for (const visibleKey of visibleKeys) {
      data.discoveredRooms[visibleKey] = true;
    }
  }

  static getVisibleRoomKeysFrom(data, x, y) {
    const keys = [];

    const candidates = [
      { x, y },
      { x: x + 1, y },
      { x: x - 1, y },
      { x, y: y + 1 },
      { x, y: y - 1 }
    ];

    for (const cell of candidates) {
      const key = this.key(cell.x, cell.y);
      if (data.rooms[key]) keys.push(key);
    }

    return keys;
  }

  static isRoomVisibleToPlayers(data, x, y) {
    const key = this.key(x, y);

    if (data.discoveredRooms[key]) return true;
    if (!data.party) return false;

    const currentlyVisible = this.getVisibleRoomKeysFrom(data, data.party.x, data.party.y);
    return currentlyVisible.includes(key);
  }

  static canMovePartyTo(data, x, y) {
    const destinationExists = Boolean(data.rooms[this.key(x, y)]);
    const destinationVisible = this.isRoomVisibleToPlayers(data, x, y);

    return destinationExists && destinationVisible;
  }

  static async clearMoveRequestAt(data, x, y) {
    data.moveRequests ??= {};

    const key = this.key(x, y);
    delete data.moveRequests[key];

    await this.deleteChatMoveRequestAt(x, y);
  }

  static async deleteChatMoveRequestAt(x, y) {
    const key = this.key(x, y);

    const chatRequest = this.chatMoveRequests?.[key];
    if (chatRequest?.messageId && game.user.isGM) {
      const message = game.messages.get(chatRequest.messageId);
      if (message) await message.delete();
    }

    delete this.chatMoveRequests[key];
  }

  static async clearInvalidMoveRequests(data) {
    data.moveRequests ??= {};

    for (const [key, request] of Object.entries(data.moveRequests)) {
      if (!data.rooms[key]) {
        delete data.moveRequests[key];
        continue;
      }

      if (!this.isRoomVisibleToPlayers(data, request.x, request.y)) {
        delete data.moveRequests[key];
        continue;
      }

      if (!this.canMovePartyTo(data, request.x, request.y)) {
        delete data.moveRequests[key];
      }
    }

    if (!game.user.isGM) return;

    for (const [key, request] of Object.entries(this.chatMoveRequests ?? {})) {
      if (!data.rooms[key]) {
        await this.deleteChatMoveRequestAt(request.x, request.y);
        continue;
      }

      if (!this.isRoomVisibleToPlayers(data, request.x, request.y)) {
        await this.deleteChatMoveRequestAt(request.x, request.y);
        continue;
      }

      if (!this.canMovePartyTo(data, request.x, request.y)) {
        await this.deleteChatMoveRequestAt(request.x, request.y);
      }
    }
  }

  static draw() {
    if (!this.ctx || !this.canvas) return;

    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;

    ctx.clearRect(0, 0, w, h);

    ctx.fillStyle = "#020402";
    ctx.fillRect(0, 0, w, h);

    this.drawBaseGrid(ctx);
    this.drawRooms(ctx);
    this.drawMoveRequests(ctx);
    this.drawParty(ctx);
  }

  static drawBaseGrid(ctx) {
    ctx.strokeStyle = "#142414";
    ctx.lineWidth = 1;

    for (let x = 0; x <= this.canvasSize; x += this.cellSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, this.canvasSize);
      ctx.stroke();
    }

    for (let y = 0; y <= this.canvasSize; y += this.cellSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(this.canvasSize, y);
      ctx.stroke();
    }
  }

  static drawRooms(ctx) {
    const data = this.getData();

    for (const [key, room] of Object.entries(data.rooms)) {
      const isGM = game.user.isGM;
      const isVisibleToPlayers = this.isRoomVisibleToPlayers(data, room.x, room.y);
      const isDiscovered = Boolean(data.discoveredRooms[key]);

      if (!isGM && !isVisibleToPlayers) continue;

      const px = room.x * this.cellSize;
      const py = room.y * this.cellSize;

      if (isVisibleToPlayers) {
        ctx.fillStyle = isDiscovered
          ? "rgba(60, 130, 60, 0.65)"
          : "rgba(60, 130, 60, 0.35)";
      } else {
        ctx.fillStyle = "rgba(40, 40, 40, 0.25)";
      }

      ctx.fillRect(px + 1, py + 1, this.cellSize - 2, this.cellSize - 2);

      ctx.strokeStyle = isVisibleToPlayers ? "#8cff8c" : "#315f31";
      ctx.lineWidth = 1;
      ctx.strokeRect(px + 1, py + 1, this.cellSize - 2, this.cellSize - 2);

      this.drawMarker(ctx, data, key, room, isVisibleToPlayers);
    }
  }

  static drawMarker(ctx, data, key, room, roomVisibleToPlayers) {
    const markerType = data.markers[key];
    if (!markerType) return;

    const marker = this.markerTypes[markerType];
    if (!marker) return;

    const isGM = game.user.isGM;

    if (!isGM) {
      if (!roomVisibleToPlayers) return;
      if (marker.gmOnly) return;
    }

    const cx = room.x * this.cellSize + this.cellSize / 2;
    const cy = room.y * this.cellSize + this.cellSize / 2;

    ctx.font = "bold 12px monospace";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    if (markerType === "boss") {
      ctx.fillStyle = "#ffffff";
    } else if (markerType === "trap") {
      ctx.fillStyle = "#ffdf80";
    } else if (markerType === "treasure") {
      ctx.fillStyle = "#ffff99";
    } else {
      ctx.fillStyle = "#ff9999";
    }

    ctx.fillText(marker.symbol, cx, cy);
  }

  static drawMoveRequests(ctx) {
    const data = this.getData();
    const allRequests = this.getAllMoveRequests(data);

    for (const [key, request] of Object.entries(allRequests)) {
      if (!data.rooms[key]) continue;

      const room = data.rooms[key];
      const visibleToPlayers = this.isRoomVisibleToPlayers(data, room.x, room.y);

      if (!game.user.isGM && !visibleToPlayers) continue;

      const cx = room.x * this.cellSize + this.cellSize / 2;
      const cy = room.y * this.cellSize + this.cellSize / 2;

      ctx.save();

      ctx.beginPath();
      ctx.moveTo(cx, cy - 8);
      ctx.lineTo(cx + 8, cy);
      ctx.lineTo(cx, cy + 8);
      ctx.lineTo(cx - 8, cy);
      ctx.closePath();

      ctx.fillStyle = "rgba(255, 255, 255, 0.85)";
      ctx.fill();

      ctx.strokeStyle = "#8cff8c";
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.font = "bold 12px monospace";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillStyle = "#020402";
      ctx.fillText("?", cx, cy + 1);

      ctx.restore();
    }
  }

  static drawParty(ctx) {
    const data = this.getData();
    if (!data.party) return;

    const { x, y } = data.party;

    if (!game.user.isGM && !this.isRoomVisibleToPlayers(data, x, y)) {
      return;
    }

    const cx = x * this.cellSize + this.cellSize / 2;
    const cy = y * this.cellSize + this.cellSize / 2;

    ctx.beginPath();
    ctx.arc(cx, cy, 6, 0, Math.PI * 2);
    ctx.fillStyle = "#ffffff";
    ctx.fill();

    ctx.strokeStyle = "#8cff8c";
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.font = "bold 10px monospace";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillStyle = "#020402";
    ctx.fillText("P", cx, cy + 1);
  }

  static eventToCell(event) {
    const rect = this.canvas.getBoundingClientRect();

    const localX = event.clientX - rect.left;
    const localY = event.clientY - rect.top;

    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;

    const canvasX = localX * scaleX;
    const canvasY = localY * scaleY;

    const x = Math.floor(canvasX / this.cellSize);
    const y = Math.floor(canvasY / this.cellSize);

    if (x < 0 || y < 0 || x >= this.gridSize || y >= this.gridSize) {
      return null;
    }

    return { x, y };
  }

  static key(x, y) {
    return `${x},${y}`;
  }

  static restorePosition(wrapper) {
    const savedPosition = game.settings.get(MODULE_ID, "position");

    if (
      savedPosition &&
      Number.isFinite(savedPosition.left) &&
      Number.isFinite(savedPosition.top)
    ) {
      wrapper.style.left = `${savedPosition.left}px`;
      wrapper.style.top = `${savedPosition.top}px`;
      wrapper.style.right = "auto";
      wrapper.style.bottom = "auto";
      return;
    }

    wrapper.style.right = "18px";
    wrapper.style.bottom = "80px";
    wrapper.style.left = "auto";
    wrapper.style.top = "auto";
  }

  static makeDraggable(wrapper, handle) {
    let isDragging = false;
    let offsetX = 0;
    let offsetY = 0;

    handle.addEventListener("mousedown", event => {
      event.preventDefault();

      isDragging = true;

      const rect = wrapper.getBoundingClientRect();

      offsetX = event.clientX - rect.left;
      offsetY = event.clientY - rect.top;

      wrapper.style.left = `${rect.left}px`;
      wrapper.style.top = `${rect.top}px`;
      wrapper.style.right = "auto";
      wrapper.style.bottom = "auto";

      document.body.classList.add("oldschool-minimap-dragging");
    });

    window.addEventListener("mousemove", event => {
      if (!isDragging) return;

      const wrapperWidth = wrapper.offsetWidth;
      const wrapperHeight = wrapper.offsetHeight;

      let nextLeft = event.clientX - offsetX;
      let nextTop = event.clientY - offsetY;

      nextLeft = Math.max(0, Math.min(window.innerWidth - wrapperWidth, nextLeft));
      nextTop = Math.max(0, Math.min(window.innerHeight - wrapperHeight, nextTop));

      wrapper.style.left = `${nextLeft}px`;
      wrapper.style.top = `${nextTop}px`;
    });

    window.addEventListener("mouseup", () => {
      if (!isDragging) return;

      isDragging = false;
      document.body.classList.remove("oldschool-minimap-dragging");

      game.settings.set(MODULE_ID, "position", {
        left: wrapper.offsetLeft,
        top: wrapper.offsetTop
      });
    });
  }
}

Hooks.once("init", () => {
  OldschoolMinimap.init();
});